const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

app.post('/save-quiz-result', (req, res) => {
  const { name, score, total } = req.body;
  const log = `Name: ${name}, Score: ${score}/${total}, Time: ${new Date().toISOString()}\n`;

  const filePath = path.join(__dirname, 'quiz-results.txt');

  fs.appendFile(filePath, log, (err) => {
    if (err) {
      console.error('Error saving result:', err);
      return res.status(500).send('Error saving result');
    }
    res.send('Result saved');
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
